# devSocial
social network in react-native stack :)
