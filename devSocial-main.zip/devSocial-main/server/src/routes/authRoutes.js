// src/routes/authRoutes.js

const express = require('express');
const router = express.Router(); // Cria um roteador Express
// server/src/routes/authRoutes.js
const authController = require('../controllers/authController');

// Rota para registro de novo usuário
router.post('/register', authController.register);

// Rota para login de usuário
router.post('/login', authController.login);

module.exports = router; // Exporta o roteador